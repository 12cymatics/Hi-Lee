# LRX Vedic Engine v5 — Ultimate Competitive Upgrade

This package is the “ultimate” upgrade on top of v4, still strictly legal (L/R/X only).

Hard additions:
- Meet-in-the-middle: backward bounded cover from all cyclic-sorted rotations, joined during forward beam.
- Stronger multi-sutra oracle: S8+S9 exact cyclic-min distances applied to 12 induced bands (anchors + phase-shift).
- Macro neighborhood expanded to reduced words length<=5.
- Deterministic basin escape tie perturbation (integer only).
- Sutra compiler reduction (XX/LR/RL + Nikhilam rotation folding).

Files:
- lrx_solver_v5.py
- verify.py
- lrx_n8_table.bin, lrx_n9_table.bin
- lrx_n8_cyclicmindist.u16, lrx_n9_cyclicmindist.u16
