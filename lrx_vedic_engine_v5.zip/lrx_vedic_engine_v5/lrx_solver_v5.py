#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""LRX Vedic Engine v5 — Ultimate Competitive Upgrade (Strict Sutra Fusion)

STRICT: Output uses ONLY primitive generators L, R, X.

Upgrades vs v4:
1) Dual-direction Vedic search: forward beam + backward bounded reachability (meet-in-the-middle).
2) Stronger oracle bundle: S8 + S9 probes on 12 bands (anchors + phase shift).
3) Macro set: all reduced words length<=5 (still legal).
4) Deterministic Maya/ZPE diversification (integer tie perturbation).
5) Cyclic goal family handled explicitly.

Run:
  python3 lrx_solver_v5.py --input test.csv --output submission.csv --time 1.2 --beam 4096 --steps 28 --backdepth 7 --selfcheck
"""

from __future__ import annotations
import argparse, csv, os, struct, time, hashlib
from typing import List, Tuple, Dict
from collections import deque

def op_L(p: Tuple[int,...]) -> Tuple[int,...]: return p[1:]+p[:1]
def op_R(p: Tuple[int,...]) -> Tuple[int,...]: return p[-1:]+p[:-1]
def op_X(p: Tuple[int,...]) -> Tuple[int,...]:
    if len(p) < 2: return p
    return (p[1], p[0]) + p[2:]

INV_MOVE = {'L':'R','R':'L','X':'X'}
MOVE_ID_TO_CHAR = {0:'L',1:'R',2:'X'}

FACT=[1]*13
for i in range(2,13):
    FACT[i]=FACT[i-1]*i

def rank_perm(p: Tuple[int,...]) -> int:
    n=len(p)
    rem=list(range(n))
    r=0
    for i,x in enumerate(p):
        j=rem.index(x)
        r += j*FACT[n-1-i]
        rem.pop(j)
    return r

def load_table(path: str):
    with open(path,'rb') as f:
        _magic=f.read(8)
        n=struct.unpack('<B', f.read(1))[0]
        N=struct.unpack('<I', f.read(4))[0]
        dist=list(struct.unpack('<%dH'%N, f.read(2*N)))
        if n<=8:
            parent_idx=list(struct.unpack('<%dH'%N, f.read(2*N)))
            root=0xFFFF
        else:
            parent_idx=list(struct.unpack('<%dI'%N, f.read(4*N)))
            root=0xFFFFFFFF
        parent_mv=bytearray(f.read(N))
    return n,N,dist,parent_idx,parent_mv,root

def load_u16(path: str, N: int):
    with open(path,'rb') as f:
        return list(struct.unpack('<%dH'%N, f.read(2*N)))

HERE=os.path.dirname(__file__)
TAB8=os.path.join(HERE,'lrx_n8_table.bin')
TAB9=os.path.join(HERE,'lrx_n9_table.bin')
CYC8=os.path.join(HERE,'lrx_n8_cyclicmindist.u16')
CYC9=os.path.join(HERE,'lrx_n9_cyclicmindist.u16')

n8,N8,dist8,par8,mv8,root8 = load_table(TAB8)
n9,N9,dist9,par9,mv9,root9 = load_table(TAB9)
cyc8 = load_u16(CYC8, N8)
cyc9 = load_u16(CYC9, N9)

def solve_exact_table(p: Tuple[int,...], n: int) -> str:
    idx=rank_perm(p)
    out=[]
    if n==8:
        par,mv,root=par8,mv8,root8
    elif n==9:
        par,mv,root=par9,mv9,root9
    else:
        raise ValueError('exact table only for n=8/9')
    while par[idx]!=root:
        mv_char=MOVE_ID_TO_CHAR[mv[idx]]
        out.append(INV_MOVE[mv_char])
        idx=par[idx]
    return ''.join(out)

def reduce_word(word: str, n: int) -> str:
    st=[]
    for c in word:
        if st:
            t=st[-1]
            if (t=='X' and c=='X') or (t=='L' and c=='R') or (t=='R' and c=='L'):
                st.pop(); continue
        st.append(c)
    folded=[]
    rot=0
    for c in st:
        if c=='L':
            rot=(rot+1)%n
        elif c=='R':
            rot=(rot-1)%n
        else:
            if rot:
                if rot<=n-rot: folded.extend('L'*rot)
                else: folded.extend('R'*(n-rot))
                rot=0
            folded.append('X')
    if rot:
        if rot<=n-rot: folded.extend('L'*rot)
        else: folded.extend('R'*(n-rot))
    st2=[]
    for c in folded:
        if st2:
            t=st2[-1]
            if (t=='X' and c=='X') or (t=='L' and c=='R') or (t=='R' and c=='L'):
                st2.pop(); continue
        st2.append(c)
    return ''.join(st2)

def inversion_count(p: List[int]) -> int:
    n=len(p)
    bit=[0]*(n+1)
    def add(i,delta):
        i+=1
        while i<=n:
            bit[i]+=delta
            i+= i&-i
    def sum_(i):
        s=0; i+=1
        while i>0:
            s+=bit[i]
            i-= i&-i
        return s
    inv=0
    for x in p:
        inv += sum_(n-1)-sum_(x)
        add(x,1)
    return inv

def circular_displacement(p: List[int]) -> int:
    n=len(p)
    pos=[0]*n
    for i,v in enumerate(p): pos[v]=i
    tot=0
    for v in range(n):
        d=abs(pos[v]-v)
        tot += min(d, n-d)
    return tot

def breakpoint_potential(p: List[int]) -> int:
    n=len(p)
    b=0
    for i in range(n):
        if p[(i+1)%n] != (p[i]+1)%n:
            b+=1
    return b

def induced_perm(p: List[int], values: List[int]) -> Tuple[int,...]:
    seq=[v for v in p if v in values]
    sv=sorted(values)
    idx={v:i for i,v in enumerate(sv)}
    return tuple(idx[v] for v in seq)

def cyclic_probe_distance(ind: Tuple[int,...]) -> int:
    k=len(ind)
    r=rank_perm(ind)
    if k==8: return cyc8[r]
    if k==9: return cyc9[r]
    raise ValueError('probe size must be 8 or 9')

def probe_bundle(p: List[int]) -> int:
    n=len(p)
    s=0
    anchors8=[0, max(0, min(n-8, (n//2)-4)), max(0, n-8)]
    anchors8 += [(a+1)%(n-7) for a in anchors8]
    for a in anchors8:
        s += 7*cyclic_probe_distance(induced_perm(p, list(range(a,a+8))))
    anchors9=[0, max(0, min(n-9, (n//2)-4)), max(0, n-9)]
    anchors9 += [(a+1)%(n-8) for a in anchors9]
    for a in anchors9:
        s += 11*cyclic_probe_distance(induced_perm(p, list(range(a,a+9))))
    return s

def score_state(p: List[int]) -> int:
    inv=inversion_count(p)
    disp=circular_displacement(p)
    br=breakpoint_potential(p)
    pb=probe_bundle(p)
    mix=br*disp
    return 5*inv + 3*disp + 17*br + pb + (mix//9)

def generate_macros(max_len: int=5) -> List[str]:
    canc={('X','X'),('L','R'),('R','L')}
    words=['']
    out=[]
    for _ in range(max_len):
        new=[]
        for w in words:
            last=w[-1] if w else None
            for c in 'LRX':
                if last and (last,c) in canc:
                    continue
                nw=w+c
                new.append(nw)
                out.append(nw)
        words=new
    out.sort(key=lambda s:(len(s),s))
    return out

MACROS=generate_macros(5)

def apply_word(p: Tuple[int,...], w: str) -> Tuple[int,...]:
    for c in w:
        if c=='L': p=op_L(p)
        elif c=='R': p=op_R(p)
        else: p=op_X(p)
    return p

def is_cyclic_sorted(p: List[int]) -> bool:
    n=len(p)
    for i in range(n):
        if p[(i+1)%n] != (p[i]+1)%n:
            return False
    return True

def final_align_to_identity(p: List[int]) -> str:
    n=len(p)
    i0=p.index(0)
    return ('L'*i0) if i0<=n-i0 else ('R'*(n-i0))

_BACK_CACHE: Dict[Tuple[int,int], Dict[Tuple[int,...], str]] = {}

def build_backward_map(n: int, backdepth: int) -> Dict[Tuple[int,...], str]:
    key=(n,backdepth)
    if key in _BACK_CACHE:
        return _BACK_CACHE[key]
    goals=[]
    g=tuple(range(n))
    for _ in range(n):
        goals.append(g)
        g=op_L(g)
    macros=[m for m in MACROS if len(m)<=3]
    def inv_word(w: str) -> str:
        return ''.join(INV_MOVE[c] for c in reversed(w))
    mp={}
    q=deque()
    for goal in goals:
        mp[goal]=''
        q.append((goal,0))
    while q:
        st,d=q.popleft()
        if d>=backdepth:
            continue
        for mw in macros:
            pre=apply_word(st, inv_word(mw))
            if pre not in mp:
                mp[pre]=mw + mp[st]
                q.append((pre, d+len(mw)))
    _BACK_CACHE[key]=mp
    return mp

def solve_with_beam_mim(p0: Tuple[int,...], beam_width: int, max_steps: int, time_limit_s: float, backdepth: int, seed: bytes) -> str:
    n=len(p0)
    t0=time.time()
    if is_cyclic_sorted(list(p0)):
        return reduce_word(final_align_to_identity(list(p0)), n)
    backmap=build_backward_map(n, backdepth)
    h=int.from_bytes(hashlib.blake2b(seed,digest_size=8).digest(),'little')
    macros=MACROS[:]
    k=h%len(macros)
    macros=macros[k:]+macros[:k]
    beam={p0:''}
    best=None
    if p0 in backmap:
        suf=backmap[p0]
        end=apply_word(p0,suf)
        best=reduce_word(suf + final_align_to_identity(list(end)), n)
    for _ in range(1, max_steps+1):
        if time.time()-t0 > time_limit_s:
            break
        cand={}
        for st,w in beam.items():
            if st in backmap:
                suf=backmap[st]
                end=apply_word(st,suf)
                sol=reduce_word(w + suf + final_align_to_identity(list(end)), n)
                if best is None or len(sol)<len(best):
                    best=sol
            for mw in macros:
                if time.time()-t0 > time_limit_s:
                    break
                ns=apply_word(st,mw)
                nw=w+mw
                prev=cand.get(ns)
                if prev is None or len(nw)<len(prev):
                    cand[ns]=nw
        if not cand:
            break
        scored=[]
        for st,w in cand.items():
            sc=score_state(list(st))
            z=int.from_bytes(hashlib.blake2b(bytes(st),digest_size=2).digest(),'little') & 7
            scored.append((sc+z, len(w), st, w))
        scored.sort(key=lambda t:(t[0],t[1]))
        beam={}
        for _,_,st,w in scored[:beam_width]:
            beam[st]=w
    return best or ''

def finisher_adjacent_sort(p: Tuple[int,...]) -> str:
    n=len(p)
    a=list(p)
    word=''
    for _ in range(n):
        for i in range(n-1):
            if a[i] > a[i+1]:
                if i:
                    a=a[i:]+a[:i]
                    word += 'L'*i
                a[0],a[1]=a[1],a[0]
                word += 'X'
                if i:
                    a=a[-i:]+a[:-i]
                    word += 'R'*i
    word += final_align_to_identity(a)
    return reduce_word(word, n)

def solve_perm(p: Tuple[int,...], time_limit_s: float, beam_width: int, max_steps: int, backdepth: int) -> str:
    n=len(p)
    if n==8:
        return reduce_word(solve_exact_table(p,8), n)
    if n==9:
        return reduce_word(solve_exact_table(p,9), n)
    seed=b'LRXVEDICV5'+bytes(p)
    w=solve_with_beam_mim(p, beam_width=beam_width, max_steps=max_steps, time_limit_s=time_limit_s, backdepth=backdepth, seed=seed)
    if w:
        return reduce_word(w, n)
    return finisher_adjacent_sort(p)

def read_perms(path: str) -> List[Tuple[int,...]]:
    perms=[]
    with open(path,'r',encoding='utf-8',newline='') as f:
        sample=f.read(4096); f.seek(0)
        if ',' in sample and 'perm' in sample:
            r=csv.DictReader(f)
            for row in r:
                s=(row.get('perm') or '').strip()
                if s: perms.append(tuple(int(x) for x in s.split()))
        else:
            for line in f:
                line=line.strip()
                if line:
                    perms.append(tuple(int(x) for x in line.replace(',',' ').split()))
    return perms

def write_moves(path: str, moves: List[str]) -> None:
    with open(path,'w',encoding='utf-8',newline='') as f:
        w=csv.writer(f)
        w.writerow(['moves'])
        for m in moves:
            w.writerow([m])

def apply_moves(p: Tuple[int,...], w: str) -> Tuple[int,...]:
    for c in w:
        if c=='L': p=op_L(p)
        elif c=='R': p=op_R(p)
        else: p=op_X(p)
    return p

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--output', required=True)
    ap.add_argument('--time', type=float, default=1.2)
    ap.add_argument('--beam', type=int, default=4096)
    ap.add_argument('--steps', type=int, default=28)
    ap.add_argument('--backdepth', type=int, default=7)
    ap.add_argument('--selfcheck', action='store_true')
    args=ap.parse_args()
    perms=read_perms(args.input)
    if not perms:
        raise SystemExit('No permutations found')
    out=[]
    for p in perms:
        n=len(p)
        if sorted(p)!=list(range(n)):
            raise ValueError(f'invalid permutation: {p}')
        w=solve_perm(p, time_limit_s=args.time, beam_width=args.beam, max_steps=args.steps, backdepth=args.backdepth)
        out.append(w)
        if args.selfcheck:
            res=apply_moves(p,w)
            if res != tuple(range(n)):
                raise RuntimeError(f'FAILED selfcheck: {p} -> {res} via {w}')
    write_moves(args.output, out)

if __name__=='__main__':
    main()
