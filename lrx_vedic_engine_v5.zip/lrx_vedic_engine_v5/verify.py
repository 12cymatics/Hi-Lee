#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, csv
def op_L(p): return p[1:]+p[:1]
def op_R(p): return p[-1:]+p[:-1]
def op_X(p):
    if len(p)<2: return p
    return (p[1],p[0])+p[2:]
def apply_moves(p,w):
    for c in w:
        if c=='L': p=op_L(p)
        elif c=='R': p=op_R(p)
        elif c=='X': p=op_X(p)
        else: raise ValueError('bad move')
    return p
def read_perms(path):
    perms=[]
    with open(path,'r',encoding='utf-8',newline='') as f:
        sample=f.read(4096); f.seek(0)
        if ',' in sample and 'perm' in sample:
            r=csv.DictReader(f)
            for row in r:
                s=(row.get('perm') or '').strip()
                if s: perms.append(tuple(int(x) for x in s.split()))
        else:
            for line in f:
                line=line.strip()
                if line: perms.append(tuple(int(x) for x in line.replace(',',' ').split()))
    return perms
def read_moves(path):
    mv=[]
    with open(path,'r',encoding='utf-8',newline='') as f:
        r=csv.DictReader(f)
        for row in r:
            mv.append((row.get('moves') or '').strip())
    return mv
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--moves', required=True)
    args=ap.parse_args()
    perms=read_perms(args.input)
    mv=read_moves(args.moves)
    if len(perms)!=len(mv):
        raise SystemExit(f'count mismatch: perms={len(perms)} moves={len(mv)}')
    for p,w in zip(perms,mv):
        res=apply_moves(p,w)
        if res!=tuple(range(len(p))):
            raise SystemExit(f'FAILED: {p} -> {res} via {w}')
    print('OK')
if __name__=='__main__':
    main()
